import requests
import pandas as pd
import smtplib
import os
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders

# Variável para armazenar a URL da API do Banco Central (URL CORRETA para funcionar o anexo)
URL = "https://www.bcb.gov.br/api/servico/sitebcb/historicotaxasjuros"

def enviar_email(mensagem, anexo=None):
    # Configurações do E-mail
    smtp_server = "smtp.gmail.com"
    smtp_port = 587
    remetente = "DIGITE SEU EMAIL AQUI" # ENTRE NO SEU EMAIL E ATIVE A FUNÇÃO "SENHA DE APP"
    senha = "DIGITE A SENHA DE APP AQUI" # <--- Cole sua senha de 16 letras aqui!
    destinatario = "DIGITE O EMAIL DO DESTINATÁRIO AQUI"

    # Cria o objeto de e-mail "caixa completa" (que aceita anexos)
    msg = MIMEMultipart()
    msg['From'] = remetente
    msg['To'] = destinatario
    
    # Define o assunto dependendo se é Sucesso (tem anexo) ou Erro (não tem anexo)
    if anexo:
        msg['Subject'] = "Relatório SELIC Atualizado (Sucesso!)"
    else:
        msg['Subject'] = "ALERTA: Falha no Robô (Erro)"

    # Adiciona o texto no corpo do e-mail
    msg.attach(MIMEText(mensagem, 'plain'))

    # Lógica para anexar o arquivo (só executa se enviarmos um nome de arquivo)
    if anexo and os.path.exists(anexo):
        try:
            # Abre o arquivo em modo leitura binária
            arquivo = open(anexo, "rb")
            parte = MIMEBase('application', 'octet-stream')
            parte.set_payload(arquivo.read())
            encoders.encode_base64(parte) # Codifica para envio
            parte.add_header('Content-Disposition', f"attachment; filename= {anexo}")
            msg.attach(parte) # Coloca o anexo na mensagem
            arquivo.close()
        except Exception as e:
            print(f"Erro ao anexar o arquivo: {e}")

    # Envia o e-mail
    try:
        server = smtplib.SMTP(smtp_server, smtp_port)
        server.starttls()
        server.login(remetente, senha)
        server.sendmail(remetente, destinatario, msg.as_string())
        server.quit()
        print(">>>> E-mail enviado com sucesso!")
    except Exception as e:
        print(f"Falha crítica ao enviar e-mail: {e}")

# --- INÍCIO DO PROGRAMA ---

try:
    print("Iniciando Captura de Dados...")

    # 1. Pega os dados
    pegar_dados = requests.get(URL, timeout=10)
    pegar_dados.raise_for_status()
    
    # 2. Processa
    response = pegar_dados.json()
    conteudo = response.get("conteudo")
    
    # 3. Gera o arquivo CSV
    df = pd.DataFrame(conteudo)
    nome_arquivo = "historico_selic.csv"
    df.to_csv(nome_arquivo, index=False)
    
    print(f"Sucesso! O Arquivo {nome_arquivo} foi atualizado.")

    # 4. ENVIA O E-MAIL COM O ANEXO
    enviar_email("Olá,\n\nSegue em anexo a planilha atualizada com as taxas SELIC.", nome_arquivo)

except Exception as erro:
    print(f"Poxa, ocorreu um problema: {erro}")
    
    # EM CASO DE ERRO: Envia e-mail só com o aviso (sem anexo)
    enviar_email(f"O script falhou ao tentar baixar os dados.\nErro técnico: {erro}")