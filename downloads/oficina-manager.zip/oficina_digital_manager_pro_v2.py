
"""
Projeto: Oficina Digital Manager PRO

By: Fabiano Santos!
"""

import tkinter as tk
from tkinter import ttk, messagebox
import sqlite3
from datetime import datetime
import os, sys

APP_NAME = "Oficina Digital Manager PRO"
DB_NAME = "oficina.db"

def resource_path(relative):
    try:
        base_path = sys._MEIPASS
    except Exception:
        base_path = os.path.abspath(".")
    return os.path.join(base_path, relative)

def conectar():
    return sqlite3.connect(resource_path(DB_NAME))

def criar_tabela():
    with conectar() as conn:
        conn.execute("""
        CREATE TABLE IF NOT EXISTS Consertos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            cliente TEXT,
            aparelho TEXT,
            defeito TEXT,
            status TEXT,
            data_entrada TEXT
        )
        """)

def inserir(cliente, aparelho, defeito):
    with conectar() as conn:
        conn.execute(
            "INSERT INTO Consertos VALUES (NULL,?,?,?,?,?)",
            (cliente, aparelho, defeito, "EM ABERTO", datetime.now().strftime("%d/%m/%Y"))
        )

def listar():
    with conectar() as conn:
        return conn.execute("SELECT * FROM Consertos ORDER BY id DESC").fetchall()

def atualizar_status(id_, status):
    with conectar() as conn:
        conn.execute("UPDATE Consertos SET status=? WHERE id=?", (status, id_))

def excluir(id_):
    with conectar() as conn:
        conn.execute("DELETE FROM Consertos WHERE id=?", (id_,))

class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(APP_NAME)
        self.geometry("1000x700")
        self.minsize(900, 600)
        self.configure(bg="#ecf0f1")

        self.columnconfigure(0, weight=1)
        self.rowconfigure(2, weight=1)

        self.style()
        self.widgets()
        self.carregar()

    def style(self):
        s = ttk.Style(self)
        s.theme_use("clam")
        s.configure("Treeview", font=("Segoe UI", 10), rowheight=28)
        s.configure("Treeview.Heading", font=("Segoe UI", 10, "bold"))
        s.configure("resolvido.Treeview", foreground="green")

    def widgets(self):
        title = tk.Label(self, text=APP_NAME, font=("Segoe UI", 20, "bold"), bg="#ecf0f1")
        title.grid(row=0, column=0, pady=10, sticky="n")

        form = tk.LabelFrame(self, text="Nova Ordem de Serviço", bg="white", padx=15, pady=15)
        form.grid(row=1, column=0, padx=20, sticky="ew")
        form.columnconfigure(1, weight=1)

        self.e_cliente = self.input(form, "Cliente:", 0)
        self.e_aparelho = self.input(form, "Aparelho:", 1)
        self.e_defeito = self.input(form, "Defeito:", 2)

        ttk.Button(form, text="Cadastrar Serviço", command=self.salvar)            .grid(row=3, column=1, pady=10, sticky="e")

        table_frame = tk.Frame(self, bg="white")
        table_frame.grid(row=2, column=0, padx=20, pady=15, sticky="nsew")
        table_frame.rowconfigure(0, weight=1)
        table_frame.columnconfigure(0, weight=1)

        cols = ("ID", "Cliente", "Aparelho", "Defeito", "Status", "Data")
        self.tree = ttk.Treeview(table_frame, columns=cols, show="headings")
        self.tree.grid(row=0, column=0, sticky="nsew")

        scrollbar = ttk.Scrollbar(table_frame, orient="vertical", command=self.tree.yview)
        scrollbar.grid(row=0, column=1, sticky="ns")
        self.tree.configure(yscrollcommand=scrollbar.set)

        for col in cols:
            self.tree.heading(col, text=col)
            self.tree.column(col, anchor="center", stretch=True)

        self.tree.tag_configure("RESOLVIDO", foreground="green")

        actions = tk.Frame(self, bg="#ecf0f1")
        actions.grid(row=3, column=0, pady=10)

        ttk.Button(actions, text="Marcar como Resolvido", command=self.concluir).grid(row=0, column=0, padx=6)
        ttk.Button(actions, text="Excluir", command=self.remover).grid(row=0, column=1, padx=6)
        ttk.Button(actions, text="Atualizar", command=self.carregar).grid(row=0, column=2, padx=6)

    def input(self, frame, text, row):
        tk.Label(frame, text=text, bg="white").grid(row=row, column=0, sticky="w")
        entry = tk.Entry(frame)
        entry.grid(row=row, column=1, pady=5, sticky="ew")
        return entry

    def salvar(self):
        if not self.e_cliente.get() or not self.e_aparelho.get() or not self.e_defeito.get():
            messagebox.showwarning("Atenção", "Preencha todos os campos.")
            return
        inserir(self.e_cliente.get(), self.e_aparelho.get(), self.e_defeito.get())
        messagebox.showinfo("Sucesso", "Serviço cadastrado.")
        self.limpar()
        self.carregar()

    def carregar(self):
        self.tree.delete(*self.tree.get_children())
        for r in listar():
            tag = "RESOLVIDO" if r[4] == "RESOLVIDO" else ""
            self.tree.insert("", "end", values=r, tags=(tag,))

    def concluir(self):
        if not self.tree.selection():
            messagebox.showwarning("Aviso", "Selecione um registro.")
            return
        item = self.tree.item(self.tree.selection())
        atualizar_status(item["values"][0], "RESOLVIDO")
        messagebox.showinfo("Atualizado", "Status alterado para RESOLVIDO.")
        self.carregar()

    def remover(self):
        if not self.tree.selection():
            messagebox.showwarning("Aviso", "Selecione um registro.")
            return
        item = self.tree.item(self.tree.selection())
        excluir(item["values"][0])
        messagebox.showinfo("Excluído", "Registro removido.")
        self.carregar()

    def limpar(self):
        for e in (self.e_cliente, self.e_aparelho, self.e_defeito):
            e.delete(0, tk.END)

if __name__ == "__main__":
    criar_tabela()
    App().mainloop()
